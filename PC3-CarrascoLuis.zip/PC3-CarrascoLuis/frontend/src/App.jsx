
import { useState, useEffect } from 'react'
import axios from 'axios'
import './App.css'

const API_enlace = '/api/universidades'

function App() {
  const [busqueda, setBusqueda] = useState('')
  const [universidades, setUniversidades] = useState([])
  const [total, setTotal] = useState(0)
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const controlador = new AbortController()
    setCargando(true)
    setError('')

    const temporizador = setTimeout(() => {
      axios.get(API_enlace, {
        params: { country: 'Peru', name: busqueda },
        signal: controlador.signal,
      })
        .then(response => {
          setUniversidades(response.data.resultados)
          setTotal(response.data.total)
          setCargando(false)
        })
        .catch(err => {
          if (axios.isCancel(err)) return 
          setError('No se pudo conectar con el backend. Verifica que el servidor Express este corriendo en el puerto 3001.')
          setCargando(false)
        })  
    }, 300)
    return () => {
      clearTimeout(temporizador)
      controlador.abort()
    }
  }, [busqueda])

  return (
    <div className='contenedor'>
      <h1>Universidades</h1>

      <input
        type='text'
        className='buscador'
        placeholder='Escribe para buscar'
        value={busqueda}
        onChange={e => setBusqueda(e.target.value)}
        autoFocus
      />

      {cargando && <p className='info'>Buscando...</p>}
      {error && <p className='error'>{error}</p>}

      {!cargando && !error && (
        <p className='info'>
          {total} resultado(s)
        </p>
      )}

      <ul className='lista'>
        {universidades.map(u => (
          <li key={u.name} className='tarjeta'>
            <h3>{u.name}</h3>
            <p>{u['state-province'] || 'Sin provincia/estado'} · {u.alpha_two_code}</p>
            {u.web_pages && u.web_pages[0] && (
              <a href={u.web_pages[0]} target='_blank' rel='noreferrer'>{u.web_pages[0]}</a>
            )}
          </li>
        ))}
      </ul>

      {!cargando && !error && total === 0 && (
        <p className='vacio'>No se encontraron universidades con "{busqueda}".</p>
      )}
    </div>
  )
}

export default App
