// backend/server.js
// Mini backend Node.js + Express que expone una API REST con JSON.
// Intenta obtener las universidades desde la API de Hipolabs; si no hay
// internet o la API falla, usa el archivo local data/universidades.json.

import express from 'express'
import cors from 'cors'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const PORT = process.env.PORT || 3001
const HIPOLABS_URL = 'http://universities.hipolabs.com/search'
const JSON_LOCAL = path.join(path.dirname(fileURLToPath(import.meta.url)), 'data', 'universidades.json')
const CACHE_MS = 10 * 60 * 1000 // 10 minutos

const app = express()
app.use(cors())
app.use(express.json())

// Quita tildes y pasa a minusculas para buscar sin importar acentos
const normalizar = (texto = '') =>
  texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim()

// Cache simple en memoria: { Peru: { datos, fuente, hora } }
const cache = {}

async function obtenerUniversidades(country) {
  const guardado = cache[country]
  if (guardado && Date.now() - guardado.hora < CACHE_MS) return guardado

  try {
    const controlador = new AbortController()
    const temporizador = setTimeout(() => controlador.abort(), 5000)
    const respuesta = await fetch(`${HIPOLABS_URL}?country=${encodeURIComponent(country)}`, {
      signal: controlador.signal,
    })
    clearTimeout(temporizador)

    if (!respuesta.ok) throw new Error(`Hipolabs respondio ${respuesta.status}`)
    const datos = await respuesta.json()
    if (!Array.isArray(datos) || datos.length === 0) throw new Error('Respuesta vacia')

    cache[country] = { datos, fuente: 'hipolabs', hora: Date.now() }
  } catch (error) {
    console.warn(`[API] Hipolabs no disponible (${error.message})`)
    const todo = JSON.parse(await readFile(JSON_LOCAL, 'utf-8'))
    const datos = todo.filter(u => normalizar(u.country) === normalizar(country))
    // El fallback se guarda solo 1 minuto para reintentar pronto con Hipolabs
    cache[country] = { datos, fuente: 'json-local', hora: Date.now() - (CACHE_MS - 60 * 1000) }
  }
  return cache[country]
}

// GET /api/universidades?country=Peru&name=cat
app.get('/api/universidades', async (req, res) => {
  try {
    const country = (req.query.country || 'Peru').toString()
    const name = normalizar((req.query.name || '').toString())

    const { datos, fuente } = await obtenerUniversidades(country)
    const resultados = name
      ? datos.filter(u => normalizar(u.name).includes(name))
      : datos

    res.json({ fuente, country, total: resultados.length, resultados })
  } catch (error) {
    console.error(error)
    res.status(500).json({ mensaje: 'Error interno del servidor' })
  }
})

app.get('/api', (req, res) => {
  res.json({ mensaje: 'API de universidades activa', endpoint: '/api/universidades?country=Peru&name=texto' })
})

app.listen(PORT, () => console.log(`API lista en http://localhost:${PORT}/api/universidades`))
